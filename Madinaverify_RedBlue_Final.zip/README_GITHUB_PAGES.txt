# Madinaverify — GitHub Pages Final Fix

Upload ALL files in this folder to the root of the `main` branch of the repository.

This version uses relative asset paths and embeds the homepage CSS directly in `index.html` so the GitHub Pages project URL `/madinaverify/` renders correctly.

GitHub Pages hosts the frontend only. The Node.js backend/API must be deployed separately.
